export default function RegisterSuccess() {
  return (
    <main style={{ textAlign: 'center', marginTop: '4rem' }}>
      <h1>Registration Successful!</h1>
      <p>Your account has been created. Please check your email for confirmation instructions.</p>
    </main>
  );
}