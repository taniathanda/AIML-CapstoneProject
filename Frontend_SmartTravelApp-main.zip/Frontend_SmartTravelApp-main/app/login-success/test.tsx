export default function LoginSuccess() {
  return (
    <main style={{ textAlign: 'center', marginTop: '4rem' }}>
      <h1>Login Successful!</h1>
      <p>Welcome to SmartTravelApp.</p>
    </main>
  );
}