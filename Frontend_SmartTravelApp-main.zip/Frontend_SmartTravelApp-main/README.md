# Command to setup
npm install
npm install bootstrap @fortawesome/fontawesome-free
npm run dev
